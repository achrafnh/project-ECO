CREATE VIEW `v_employee_hermes` AS
