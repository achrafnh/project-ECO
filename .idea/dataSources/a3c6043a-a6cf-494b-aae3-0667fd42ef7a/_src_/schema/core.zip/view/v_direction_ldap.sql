CREATE VIEW `v_direction_ldap` AS
