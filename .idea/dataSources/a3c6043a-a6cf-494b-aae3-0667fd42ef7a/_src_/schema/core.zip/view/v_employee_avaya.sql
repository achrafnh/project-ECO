CREATE VIEW `v_employee_avaya` AS
